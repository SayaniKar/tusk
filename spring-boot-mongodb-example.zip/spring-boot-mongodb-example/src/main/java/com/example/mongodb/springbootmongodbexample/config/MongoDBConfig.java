package com.example.mongodb.springbootmongodbexample.config;
import com.example.mongodb.springbootmongodbexample.document.Users;
import com.example.mongodb.springbootmongodbexample.repository.UserRepository;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;


@EnableMongoRepositories(basePackageClasses= UserRepository.class)
@Configuration
public class MongoDBConfig {
	@Bean
	CommandLineRunner  commandLineRunner (UserRepository userRepository) {
		
			return Strings->{
				userRepository.save(new Users(1,"AA","Developer",3000L));
				userRepository.save(new Users(2,"BB","Developer",4000L));

				
				};
		
	}

}
