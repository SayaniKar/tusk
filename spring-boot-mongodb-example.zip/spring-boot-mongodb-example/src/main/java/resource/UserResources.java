package resource;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.mongodb.springbootmongodbexample.document.Users;
import com.example.mongodb.springbootmongodbexample.repository.UserRepository;

@RestController
@RequestMapping("/rest/users")
public class UserResources {
	private UserRepository userRepository;
	
	public void UsersResource(UserRepository userRepository)
	{
		this.userRepository=userRepository;
	}
	@GetMapping("/all")
	public List<Users> getAll()
	{
		return userRepository.findAll();
	}

}
