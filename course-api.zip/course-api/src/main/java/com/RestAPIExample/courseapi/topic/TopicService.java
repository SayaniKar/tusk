package com.RestAPIExample.courseapi.topic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Service
public class TopicService {
	 private List<Topic> topics=new ArrayList<>(Arrays.asList(
			new Topic("Spring","Spring FrameWork","Spring is a framework"),
			new Topic("Hibernate"," Detials of Hibernate","Hibernate is an ORM tool")
			));
	
public List<Topic> getAllTopic()
{
	return topics;
}
public Topic getTopic(String id)
{
	return topics.stream().filter(t->t.getId().equals(id)).findFirst().get();
}
public void addTopic(Topic topic)
{
	topics.add(topic);
	}
public void deleteTopic(String id)
{
	topics.removeIf(t->t.getId().equals(id));
}
}
